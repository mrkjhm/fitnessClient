import { Button, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Banner from '../components/Banner';
// import WorkoutCard from '../components/WorkoutCard';
import AllWorkouts from '../components/AllWorkouts';


export default function Home() {

	return (
		<>
        <Banner />
        <AllWorkouts />

        {/* <Row>
            <Col className="p-4 text-center">
            
                <h1>Welcome To FitnessClub</h1>
            
                <Link className="btn btn-primary" to={"/login"}>Check you workout</Link>
            </Col>
        </Row>  */}
		</>
	)
}