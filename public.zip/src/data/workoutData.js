const WorkoutData = [
	{
		
		name: "Runing",
		duration: "10 mins",
		status: 'pending'
	}, 
	{
		
		name: "Jogging",
		duration: "10 mins",
		status: 'pending'
	}, 
	
]

export default WorkoutData; 