// import { useState } from 'react';
// import { Card, Button } from 'react-bootstrap';
// import { Link } from 'react-router-dom';

// export default function WorkoutCard({workoutProp}) {

//     // console.log(courseProp)
//     const { name, duration} = workoutProp;

//     return (
//         <Card className='m-2'>
//             <Card.Body>
//                 <Card.Title>{name}</Card.Title>
//                 <Card.Subtitle>Duration:</Card.Subtitle>
//                 <Card.Text>{duration}</Card.Text>            
//                 <Button variant="primary" >Details</Button>
//             </Card.Body>
//         </Card>
//     )
// }