import { Form, Button} from 'react-bootstrap';
import { useNavigate, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Swal from 'sweetalert2';



export default function AddWorkout(){

    const [name, setName] = useState("");
	const [duration, setDuration] = useState("");
    const [isActive, setIsActive] = useState(false);

    const navigate = useNavigate();

    function addWorkout(e){
        e.preventDefault();

        fetch('https://app-building-api.onrender.com/workouts/addWorkout', {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({
                name: name,
                duration: duration,
            })
        })
        .then(res => res.json())
        .then(data => {
            console.log(data);
            if (data.error === false) {

                Swal.fire({
                    title: "Unsuccessful Workout Creation",
                    icon: "error",
                });
                
              
                
            } else {
                Swal.fire({
                    title: "Workout Added",
                    icon: "success",
                });
                setName('');
                setDuration('');
            // navigate("/");
            }
        })
        .catch(err => console.error('Error:', err));
    }

	useEffect(() => {
		if(name !== "" && duration !== "") {
            setIsActive(true)
        } else {
            setIsActive(false)
        }

	}, [name, duration])

    return (
        <Form onSubmit={(e) => addWorkout(e)}>

            <h1 className='text-center mt-5'>Add Workout</h1>
            <Form.Group className="mb-3" controlId="formName">
                <Form.Label>Name:</Form.Label>
                <Form.Control
                    type="text" 
                    placeholder="Enter Name"
                    required
                    value={name}
                    onChange={e => {setName(e.target.value)}}
                />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formName">
                <Form.Label>Duration:</Form.Label>
                <Form.Control
                    type="text" 
                    placeholder="Enter Duration"
                    required
                    value={duration}
                    onChange={e => {setDuration(e.target.value)}}
                />
            </Form.Group>

            
            { isActive ?
            	<Button variant="primary" type="submit" id="submitBtn">Submit</Button>
            	:
            	<Button variant="danger" type="submit" id="submitBtn" disabled>Submit</Button>
        	}
          
        </Form>
    )

}
