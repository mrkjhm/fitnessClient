// import { useState, useEffect } from 'react';

import React, { useEffect, useState } from 'react';


import workoutData from '../data/workoutData';



// export default function MyWorkout() {
    

    

//     return(
//         <>
//         <AddWorkout />
//             <h1 className="text-center my-4"> My Workout</h1>
//             <Button variant="primary" type="submit" id="submitBtn">Submit</Button>
//             <Table striped bordered hover responsive>
//                 <thead>
//                     <tr className="text-center">
//                         <th>Name</th>
//                         <th>Duration</th>
//                         <th>Status</th>
           
//                         <th colSpan="2">Actions</th>
//                     </tr>
//                 </thead>

//                 <tbody>
//                     {}
//                 </tbody>
//             </Table>    
//         </>

//         )
// }


// const MyWorkout = () => {
//     const [workouts, setWorkouts] = useState([]);
  
//     useEffect(() => {
//       const fetchWorkouts = async () => {
//         try {
//           const response = await fetch('https://app-building-api.onrender.com/workouts/getMyWorkouts', {
//             headers: {
//               Authorization: `Bearer ${localStorage.getItem('token')} `
//             }
//           });
//           const data = await response.json();
//           setWorkouts(data);
//         } catch (error) {
//           console.error('Error fetching workouts:', error);
//         }
//       };
  
//       fetchWorkouts();
//     }, []);
  
//     return (
//         <>
//         <AddWorkout />
//       <div>


//         <h1>My Workout</h1>
//         <table className="table">
//           <thead>
//             <tr>
//               <th>Name</th>
//               <th>Duration</th>
//               <th>Status</th>
//               <th>Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {workouts.map((workout) => (
//               <tr key={workout.id}>
//                 <td>{workout.name}</td>
//                 <td>{workout.duration}</td>
//                 <td>{workout.status}</td>
//                 <td>
//                   {/* Add actions like edit or delete here */}
//                   <button>Edit</button>
//                   <button>Delete</button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>

//       </>
//     );
//   };
  
//   export default MyWorkout;



const MyWorkout = () => {
  const [workouts, setWorkouts] = useState([]);

  useEffect(() => {
    const fetchWorkouts = async () => {
      try {
        const response = await fetch('https://app-building-api.onrender.com/workouts/getMyWorkouts', {
            headers: {
              Authorization: `Bearer ${localStorage.getItem('token')} `
            }
        });
        const data = await response.json();
        setWorkouts(data);
      } catch (error) {
        console.error('Error fetching workouts:', error);
      }
    };

    fetchWorkouts();
  }, [workoutData]);

  return (
    <>
    
    <div>
      <h1>My Workout</h1>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Duration</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {workoutData.map((workout) => (
            <tr key={workout.id}>
              <td>{workout.name}</td>
              <td>{workout.duration}</td>
              <td>{workout.status}</td>
              <td>
                {/* Add actions like edit or delete here */}
                <button>Edit</button>
                <button>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </>
  );
};

export default MyWorkout;
