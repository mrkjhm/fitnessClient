import { useEffect, useState } from 'react';

export default function AllWorkouts() {

    const [workouts, setWorkout] = useState([]);

    useEffect(() => {
        fetch('https://app-building-api.onrender.com/workouts/getMyWorkouts')
            .then(res => res.json())
            
            .then(data => {
                // Ensure the data is an array before setting the state
                if (Array.isArray(data)) {
                    setWorkout(data);
                } else {
                    console.error("Expected an array but got:", data);
                    setWorkout([]);
                }
            })
            .catch(err => console.log(err));
    }, []);

    // return (
    //     <div>
    //         <h1>All Workouts</h1>
    //         <ul>
    //             {Array.isArray(workouts) && workouts.length > 0 ? (
    //                 workouts.map((list, index) => (
    //                     <li key={index}>{list.id} | {list.name}</li>
    //                 ))
    //             ) : (
    //                 <p>No workouts found.</p>
    //             )}
    //         </ul>
    //     </div>
    // );
}
