import { useState } from 'react';
import { Button, Modal, Form } from 'react-bootstrap';
import Swal from 'sweetalert2';

export default function EditWorkout({ workout, fetchData }) {

	// States for the edit form
	const [ name, setName ] = useState("");
	const [ duration, setDuration ] = useState("");
	const [ intensity, setIntensity ] = useState(0);
	// State for opening/closing the modal
	const [ showEdit, setShowEdit ] = useState(false);

	// function for opening the modal
	const openEdit = (workoutId) => {
		fetch(`${process.env.REACT_APP_API_URL}/workouts/specific/${workoutId}`)
		.then(res => res.json())
		.then(data => {
			console.log(data);
			setName(data.name);
			setDuration(data.duration);
			setIntensity(data.intensity);
		})
		// open the modal
		setShowEdit(true);
	}

	// function for closing the modal
	const closeEdit = () => {
		setShowEdit(false);
		setName("");
		setDuration("");
		setIntensity(0);
	}

	// function to update the workout
	const editWorkout = (e, workoutId) => {
		e.preventDefault();
		fetch(`'https://app-building-api.onrender.com/workouts/updateWorkout/${workoutId}`, {
			method: 'PATCH',
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${localStorage.getItem('token')}`
			},
			body: JSON.stringify({
				name: name,
				duration: duration,
				intensity: intensity
			})
		})
		.then(res => res.json())
		.then(data => {
			console.log(data);

			if(data.message === "Workout updated successfully"){
				Swal.fire({
					title: "Success!",
					icon: "success",
					text: "Workout successfully updated"
				});
				closeEdit();
				fetchData();
			} else {
				Swal.fire({
					title: "Error!",
					icon: "error",
					text: "Please try again"
				});
				closeEdit();
				fetchData();
			}
		});
	}

	return(
		<>
			<Button variant="primary" size="sm" onClick={() => openEdit(workout)}>Edit</Button>

			{/*EDIT MODAL*/}
			<Modal show={showEdit} onHide={closeEdit}>
			    <Form onSubmit={e => editWorkout(e, workout)}>
			        <Modal.Header closeButton>
			            <Modal.Title>Edit Workout</Modal.Title>
			        </Modal.Header>
			        <Modal.Body>    
			            <Form.Group controlId="workoutName">
			                <Form.Label>Name</Form.Label>
			                <Form.Control 
			                	type="text"
			                	required
			                	value={name}
			                	onChange={e => setName(e.target.value)}
			                />
			            </Form.Group>
			            <Form.Group controlId="workoutDuration">
			                <Form.Label>Duration</Form.Label>
			                <Form.Control 
			                	type="text" 
			                	required
			                	value={duration}
			                	onChange={e => setDuration(e.target.value)}
			                />
			            </Form.Group>
			            <Form.Group controlId="workoutIntensity">
			                <Form.Label>Intensity</Form.Label>
			                <Form.Control 
			                	type="number" 
			                	required
			                	value={intensity}
			                	onChange={e => setIntensity(e.target.value)}
			                />
			            </Form.Group>
			        </Modal.Body>
			        <Modal.Footer>
			            <Button variant="secondary" onClick={closeEdit}>Close</Button>
			            <Button variant="success" type="submit">Submit</Button>
			        </Modal.Footer>
			    </Form>
			</Modal>
		</>
	);
}
